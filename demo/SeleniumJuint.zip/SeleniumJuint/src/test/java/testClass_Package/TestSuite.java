package testClass_Package;

import dataProvider.TestData;
import org.junit.runner.RunWith;
import org.junit.runners.Suite;



@RunWith(Suite.class)

@Suite.SuiteClasses (
        {

        }
)

public class TestSuite {
        public static void main(String[] args) {

        }

}
