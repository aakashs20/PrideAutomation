package com.project.utilities.enums;

public enum NavigationType {
    Absolute, Relative
}
