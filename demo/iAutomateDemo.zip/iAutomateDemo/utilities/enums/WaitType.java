package com.project.utilities.enums;

public enum WaitType {
    WhenClickable, WhenVisible, WhenPresent
}
